require('../../common/options')('bulma')
